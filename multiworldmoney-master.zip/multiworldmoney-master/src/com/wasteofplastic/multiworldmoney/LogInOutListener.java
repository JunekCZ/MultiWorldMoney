package com.wasteofplastic.multiworldmoney;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static org.bukkit.Bukkit.getLogger;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class LogInOutListener implements Listener {

    private MultiWorldMoney plugin;

    /**
     * @param plugin
     */
    public LogInOutListener(MultiWorldMoney plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(final PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Add player to the cache
        plugin.getPlayers().addPlayer(player);
        // Set the balance for this player in whatever world they are in because it may have changed while
        // they were offline
        double balance = VaultHelper.econ.getBalance(player);
        plugin.getPlayers().setBalance(player, player.getWorld(), balance);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(final PlayerQuitEvent event) throws SQLException {
        if(plugin.mysql) {
            Player player = event.getPlayer();
            for (World world : plugin.getGroupWorlds(event.getPlayer().getWorld())) {
                double oldBalance = plugin.roundDown(VaultHelper.econ.getBalance(player), 2);
                String name = player.getName();
                Statement statement = plugin.c.createStatement();
                ResultSet res = statement.executeQuery("SELECT id, money, PlayerName FROM MultiWorldMoney WHERE PlayerName='" + name + "' AND world='" + world.getName() + "';");
                if(res.next()) {
                    int update = statement.executeUpdate("UPDATE MultiWorldMoney SET money='" + oldBalance + "' WHERE world='" + world.getName() + "' AND PlayerName='" + name + "';");
                    if(update == 0) {
                        getLogger().info(" -- Some error message, while updating -- ");
                    }
                } else {
                    int insert = statement.executeUpdate("INSERT INTO MultiWorldMoney (PlayerName, money, world) VALUES ('" + name + "', '" + oldBalance + "', '" + world.getName() + "');");
                    if(insert == 0) {
                        getLogger().info(" -- Some error message, while inserting -- ");
                    }
                }
            }
        }
        // Remove player
        plugin.getPlayers().removePlayer(event.getPlayer());
    }
}