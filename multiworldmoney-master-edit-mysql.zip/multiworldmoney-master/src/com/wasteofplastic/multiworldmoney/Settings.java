package com.wasteofplastic.multiworldmoney;

public class Settings {

    public static String newWorldMessage;
    public static boolean showBalance;

}
